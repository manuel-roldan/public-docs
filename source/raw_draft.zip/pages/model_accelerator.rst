.. _model_accelerator:

Model Accelerator
#################