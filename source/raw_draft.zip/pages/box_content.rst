.. _fw_boardsw:

Firmware & Board Software
#########################

This appendix describes the following topics:
* Flashing tRoot remotely without SPI Flashing tool
* Flashing SD card image from the Host PC
* Flashing eMMC from the target device

All these functions are described here in details.


Download the SiMa.ai MLSoC images
---------------------------------

Go to the `developer webpage <https://developer.sima.ai/>`_. 
You can find the CLI zip under `Files` -> `Palette 1.0.0 Release Deliverables` -> `Software` -> `MLSoC_1.0.0.tar`.

Unzip the SiMa.ai MLSoC files
-----------------------------

Under the folder where you downloaded the `.tar` file:

..  code-block:: console

    $ tar -xvf MLSoC_1.0.0.tar.gz
    $ cd to the folder whatever....

Firmware/tRoot Upgrade Steps
----------------------------

You can find the tRoot file named `troot_blob.be` in this folder. We will copy this file to the SoC.
For this example we will assume that the board has the default `192.168.1.20` IP address.

..  code-block:: console

    $ scp troot_blob.be sima@192.168.1.20:/tmp
    sima@192.168.1.20:'s password:
    troot_blob.be                      100%    0     0.0KB/s   00:00


.. note::

    The password for the default sima user on the board is `edgeai`

Now let's connect to the board, we can use the serial port using a tool like minicom or ssh through the ethernet port.
For this example I will use ssh. We will login as root to update the firmware.

..  code-block:: console

    ssh root@192.168.1.20


.. note::

    The password for the default root user on the board is `commitanddeliver`

Let's update the firmware:

..  code-block:: console

    sudo troot_upgrade

If `troot_blob.be`` is not copied to `/tmp`` path, then use:

..  code-block:: console

    sudo troot_upgrade /path/to/file/troot_blob.be

Wait until Flash Write is complete. Note that this will take a long time to complete (>10 minutes
in some cases).
The output of a successful upgrade will display the following:

..  code-block:: console

    SUCCESS SUCCESS - spi upgrade sucessful, data match passed

If the success message appears, power cycle the board. Verify the board boots properly by checking the version/messages in the tRoot terminal. If the
board does not boot, contact support@sima.ai.



Flashing SD Card Image From the Host PC
---------------------------------------

TODO

Flashing eMMC From the Target Device
------------------------------------

TODO


.. note::

    We use the Linux bmaptool which allows a significant reduction of the time required for image flashing to the
    target device (SD Card or eMMC). It is achieved by using a “bmap” (block map) file that describes
    which blocks contain data that can be flashed.