.. _palette_cli:

Palette CLI
###########

In this section we will get your host development environment up and running
with the necessary software needed to build applications and connect to the MLSoC Evaluation
Board. The following topics are covered in this chapter:

* Setting up the CLI SDK
* Setting up the MLSoC Evaluation Board for CLI usage
* Troubleshooting and resolving IP Address issue without IT support


Linux
*****

Download the SiMa.ai CLI SDK
----------------------------

Go to the `developer webpage <https://developer.sima.ai/>`_. You can find the CLI zip under `Files` -> `Palette 1.0.0 Release Deliverables` -> `Software` -> `Palette_CLI_1.0.0_release`.

Unzip the SiMa.ai CLI SDK
-------------------------
 
Unzip to a local directory and change your directory to `1.0.0_develop_B495/sima-cli`:

..  code-block:: console

    $ unzip Palette_CLI_1.0.0_release.zip
    Archive:  Palette_CLI_1.0.0_release.zip
        creating: 1.0.0_develop_B495/
        creating: 1.0.0_develop_B495/sima-cli/
        inflating: 1.0.0_develop_B495/sima-cli/uninstall.sh  
        inflating: 1.0.0_develop_B495/sima-cli/start.sh  
        inflating: 1.0.0_develop_B495/sima-cli/release-notes.txt  
        inflating: 1.0.0_develop_B495/sima-cli/simaclisdk_1_0_0_develop_B495.tar  
        inflating: 1.0.0_develop_B495/sima-cli/stop.sh  
        inflating: 1.0.0_develop_B495/sima-cli/install.sh
    $ cd 1.0.0_develop_B495/sima-cli/
    $ ls
    install.sh  release-notes.txt  simaclisdk_1_0_0_develop_B495.tar  start.sh  stop.sh  uninstall.sh

The output of this command would be similar to the screen shown above. It will take a
couple of minutes to complete the Docker image extraction.

.. warning:: 
    Our SDK uses docker, we recommend you to add your user to the docker group if you haven't done it already.
    You can follow the docker post installation steps using the `official documenation <https://docs.docker.com/engine/install/linux-postinstall/>`_.
    If you prefer to not perform these steps make sure to run every script on this page using `sudo`, for instance `sudo install.sh`.


.. note:: 
    Before Installing the SDK:

    #. If you have already installed the CLI SDK in the past. Stop the container before proceeding to install the new SDK version. This ensures that any ongoing processes using the SDK are gracefully terminated.
    #. Run the `uninstall.sh` script.
    #. Select `y` for both prompts that follow.

Installing the SDK
------------------

Run `install.sh` and set up the docker shared directory.

..  code-block:: console

    $ ./install.sh
    Checking if SiMa CLI version 1.0.0_develop_B495 is already installed...
    Loading Docker image version 1.0.0_develop_B495...
    954c82bdeb5f: Loading layer [==================================================>] 75.17MB/75.17MB
    95556e8bdd6c: Loading layer [==================================================>]
    .
    .
    .
    0a727a177e85: Loading layer [==================================================>] 3.584kB/3.584kB
    Loaded image: simaclisdk:1.0.0_develop_B495
    Enter work directory [/home/demo_user/sima_cli_workspace]:
    Checking SiMa SDK Bridge Network...
    SiMa SDK Bridge Network found.
    b1ea6cd4e47807e2cd78d440ae348c704d420720041c953da2c31169058dd7f5
    Installation successful. To log in to the Docker container, please use the './start.sh'
    script
    Your local work directory '/home/demo_user/sima_cli_workspace' has been mounted to
    '/home/docker/sima-cli'

Enter the work directory which will be mounted inside the Docker container as shown in the prompt below. 
This work directory will be shared between the Docker SDK image and the host machine and can be the place where you place most of your development
files so that they persist even after the container is shut down. In this case, the default
directory is shown, but you may choose any other directory on the host machine.

.. note:: The default work directory suggested by the install script will not be the same for all users.


Start the SDK
-------------

Start the container and login.

..  code-block:: console

    $ ./start.sh
    Checking if the container is already running...
    ==> Container is already running. Proceeding to start an interactive shell.
    demo_user@b1ea6cd4e478:/home$ ps aux
    USER PID %CPU %MEM VSZ RSS TTY STAT START TIME COMMAND
    demo_user 1 0.0 0.0 30936 23120 pts/0 Ss+ 17:24 0:00 /usr/bin/python3
    /usr/bin/supervisord -n -c /etc/supervisor/conf.d/supervisord.conf
    demo_user 53 1.2 0.7 13036324 230840 pts/0 Sl 17:24 0:17 java -jar rpmservice.jar
    demo_user 57 1.0 0.7 13036324 244672 pts/0 Sl 17:24 0:15 java -jar plugincompilation.jar
    demo_user 58 0.2 0.3 118832 105684 pts/0 S 17:24 0:02 python
    device_status_shadow.py -v
    demo_user 59 1.1 0.7 12969756 245480 pts/0 Sl 17:24 0:16 java -jar gstgenerator-service.jar
    demo_user 60 0.1 0.3 488868 106516 pts/0 Sl 17:24 0:01 python
    local_port_forwarding.py -v
    demo_user 61 1.1 0.7 12969756 235404 pts/0 Sl 17:24 0:15 java -jar packagingservice.jar
    demo_user 62 0.6 0.5 12903192 194192 pts/0 Sl 17:24 0:09 java -jar performanceestimator.jar
    demo_user 63 0.0 0.2 479536 97700 pts/0 Sl 17:24 0:01 python
    remote_port_forwarding.py -v
    demo_user 199 0.0 0.2 267672 95720 pts/0 Sl 17:24 0:00 python
    local_port_forwarding.py -v
    demo_user 363 0.1 0.0 7104 3928 pts/1 Ss 17:47 0:00 bash
    demo_user 370 0.0 0.0 8888 3168 pts/1 R+ 17:47 0:00 ps aux

Testing the SDK
---------------

Let's run our building and deployment software contained in our SDK, the `mpk` package.

..  code-block:: console

    $ mpk --help
    usage: mpk [-h] [-d] [-q] [-v] {remote-log,device,create,debug,deploy,firmwareupgrade,kill,launch,list,pe,remove} ...
    SiMa CLI Tool
    options:
    -h, --help show this help message and exit
    -d, --debug full application debug mode
    -q, --quiet suppress all console output
    -v, --version show program's version number and exit
    sub-commands:
    {remote-log,device,create,debug,deploy,firmware-upgrade,kill,launch,list,pe,remove}
    remote-log remote-log controller
    device device controller
    create create mpk from directory
    debug debug a running package or deploy mpk in debug mode
    deploy Deploy mpk to target
    firmware-upgrade Upgrade or Reset a device
    kill Kill the current running package
    launch Launch previously deployed mpk
    list List the current running packages
    pe Run Performance Estimator
    remove Remove previously deployed mpk

Installation video
------------------

.. video:: ../_static/set_cli.mp4
    :height: 400
    :width: 650


Windows
*******

TODO


MacOS (intel CPU)
*****************

TODO

MacOS (M1 or M2 CPU)
********************

Not supported
