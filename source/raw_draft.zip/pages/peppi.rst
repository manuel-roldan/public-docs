.. _peppi:

Peppi
#####

Introduction
============

Peppi is SiMa's solution to reduce the friction for new users to implement semi performant pipelines - 10 to 30 fps pipelines.
The Peppi platform uses python to run pipelines entirely on the board. This provides a high level of flexibility since our users can install any python external library and combine them with our optimized sima kernels for pre and post processing operations while the model runs entirely in our Accelerated hardware.
All the external libraries like matplotlib will target our ARM A65. The different kernels will run sequentially. These 2 reasons are why the fps count has some performance limitations.


Running your first example
==========================

Requirements
------------

#. Have a board available to run the peppi examples.
#. Your board must be using SiMa's latest software, if you haven't already check how to update it on Chapter 3.5.
#. Your Palette CLI SDK must be using the latest version, check Chapter 3.2.
#. Your board must be connected with your machine over ethernet.

.. note:: 

    This example assumes an Ubuntu host. However the steps should be easily follow in any other OS.

Resnet50 example
----------------

The first example that we will be running is a classic.
This example should give you enough details to be able to run your own models.

#. Let's `download <https://developer.sima.ai/peppi_examples/>`_ the files needed to run this example.
#. Copy the files to the shared folder between the Palette CLI SDK and your host machine, for the commands we will be using the default folder called ``workspace``, if you changed the name of your shared folder replace it:

    ..  code-block:: console

        sima-user@sima-user-machine:~$ 
        sima-user@sima-user-machine:~$ cd Downloads/
        sima-user@sima-user-machine:~/Downloads$ mv peppi_examples.zip ~/workspace


#. Now we will proceed to compile our resnet50 example, refer to Chapter 8 to learn how to compile models in depth.
    * Start your Palette CLI SDK by running the `start.sh` command. Check out Chapter 3.2 if you don't remember how.
    * Once you are running inside of the SDK let's compile our resnet50 model:

    ..  code-block:: console

        sima-user@docker-image-id:/home# cd /home/docker/sima-cli/peppi_examples/
        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# python3 compile_resnet50.py
            Compiling model resnet50_v1_opt.onnx with arm_only=False
            Running calibration ...DONE
            Running quantization ...DONE
            2023-12-01 04:19:34,462 - afe.apis.model - INFO - Compiling quantized net "resnet50_v1_opt"
            2023-12-01 04:19:34,726 - mlc.compiler.model_graph.l1_based - INFO - Get model compilation properties
            2023-12-01 04:19:34,728 - mlc.compiler.model_graph.l1_based - INFO - Setting layer parameters
            2023-12-01 04:19:34,729 - mlc.compiler.model_graph.l1_based - INFO - Checking if layers fit into memory without splitting
            2023-12-01 04:19:34,729 - mlc.compiler.model_graph.l1_based - INFO - Generating the list of feasible layouts
            2023-12-01 04:19:39,872 - mlc.compiler.model_graph.l1_based - INFO - Setting tile layouts
            2023-12-01 04:19:44,884 - mlc.compiler.model_graph.l1_based - INFO - Allocating memory for IFM/OFM tensors
            2023-12-01 04:19:45,082 - mlc.compiler.model_graph.l1_based - INFO - Get model compilation properties done
            2023-12-01 04:19:45,102 - mlc.kernel.layout - INFO - L2 caching mode: L2CachingMode.NONE
            2023-12-01 04:19:45,112 - mlc.compiler.model_graph.l1_based - INFO - Generating model code
            2023-12-01 04:19:52,291 - mlc.compiler.model_graph.l1_based - INFO - Generating model code done
            2023-12-01 04:19:52,373 - mlc.test_util.test_context - INFO - Scheduling instructions
            2023-12-01 04:20:03,908 - mlc.test_util.test_context - INFO - Performing DRAM/L2 synchronization
            2023-12-01 04:20:04,488 - mlc.test_util.test_context - INFO - Inserting and merging NOPs
            2023-12-01 04:20:04,646 - mlc.test_util.test_context - INFO - Setting IQ sync bits
            2023-12-01 04:20:04,853 - mlc.test_util.test_context - INFO - Checking quadrants
            2023-12-01 04:20:04,854 - mlc.test_util.test_context - INFO - Generating metrics
            2023-12-01 04:20:04,977 - mlc.test_util.test_context - INFO - Lowering instructions
            2023-12-01 04:20:07,865 - mlc.test_util.test_context - INFO - Writing report to MLC file
            2023-12-01 04:20:07,866 - mlc.test_util.test_context - INFO - Writing instructions to MLC file
            2023-12-01 04:20:19,411 - mlc.test_util.test_context - INFO - Code generation done
            2023-12-01 04:20:31,032 - autotvm - INFO - Download pre-tuned parameters package from https://raw.githubusercontent.com/tlc-pack/tophub/main/tophub/arm_cpu_v0.08.log
            2023-12-01 04:20:31,032 - download - INFO - Downloading from url https://raw.githubusercontent.com/tlc-pack/tophub/main/tophub/arm_cpu_v0.08.log to /root/.tvm/tophub/arm_cpu_v0.08.log
            2023-12-01 04:20:31,743 - te_compiler - INFO - Using injective.arm_cpu for cast based on highest priority (10)
        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# ls
        calibration  compile_resnet50.py  debug.log  output  README.md  resnet50_v1_opt.onnx  sdk  test_resnet50_v1.py data
        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# ls output/
        resnet50_v1_opt_mpk.tar.gz

    * The resulting file ``resnet50_v1_opt_mpk.tar.gz`` should be inside of the ``output`` folder.
  
#. Now we will create a ``.tar.gz`` file with the required files:

    ..  code-block:: console

        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# tar -cvzf test_resnet.tar.gz output/resnet50_v1_opt_mpk.tar.gz test_resnet50_v1.py data/imagenet_img data/imagenet1000_clsidx_to_labels.txt


#. Let's copy the required files to our board to run the example:


    ..  code-block:: console

        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# scp test_resnet.tar.gz sima@{board_ip_address}:/home/sima/


#. Let's log in into the board and run the example, for this step we will need to log in as root.

    .. note:: 

        Remember that the password for the user ``root`` is ``commitanddeliver`` by default.

    ..  code-block:: console

        sima-user@docker-image-id:/home/docker/sima-cli/peppi_examples# ssh root@{board_ip_address}
        The authenticity of host '192.168.1.20 (192.168.1.20)' can't be established.
        ECDSA key fingerprint is SHA256:GE2O0nsfBw8tpPUANpa7JyOXmMAhQPuKht+N6Nu6HDI.
        Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
        Warning: Permanently added '192.168.1.20' (ECDSA) to the list of known hosts.
        root@192.168.1.20's password: 
        Last login: Mon Nov 27 14:49:45 2023

        root@davinci:~# cd /home/sima
        root@davinci:/home/sima# tar -xvzf test_resnet.tar.gz
        root@davinci:/home/sima# export PYTHONPATH=/usr/lib/python3.10/site-packages/sima:/usr/lib/python3.10/site-packages/partitioned_model_manager:/usr/lib/python3.10/site-packages/mla_rt_service
        root@davinci:/home/sima# python3 test_resnet50_v1.py --image_width 1280 --image_height 720 --max_frames 10 --model_tgz resnet50_v1_opt_mpk.tar.gz
        TODO: Show the output when we get the image data


#. That's it! You have succesfully ran your first Peppi pipeline!

Analysis of the Peppi resnet50 file
-----------------------------------

In this section we will walk together though the ``test_resnet50_v1.py`` code. Let's start directly on the main which is contained in the ``run_test(args)`` function.

..  code-block:: python

    def run_test(args):
        # Create an MLSoCRT object.
        sess = sima.MLSoCRT(args.model_tgz, args.image_height, args.image_width)


The first sima specific command is ``sima.MLSoCRT``. This command creates a session for our model accessing it's ``tar.gz`` file. checkout Chapter TODO {Peppi' API chapter number} for more information.

..  code-block:: python

    # Load all image files.
    if not os.path.exists(args.images_path):
        raise Exception(f"[ ERROR ] Path to images {args.images_path} is invalid")
    
    images_list = get_all_files(args.images_path, include_type="image")
    if (len(images_list) <= 0):
        raise Exception(f"[ ERROR ] No image files found in {args.images_path}")

    # Load the label dictionary to be used for prediction.
    id_label_dict = get_id_label_dict(os.path.join(args.images_labels_path, CLSIDX_TO_LABELS_PATH))
    if not id_label_dict:
        raise Exception(f"[ ERROR ] Dictionary mapping class indices to labels is empty")

    # Determine the total number of frames to process.
    if args.max_frames < len(images_list):
        num_frames = args.max_frames
    else:
        num_frames = len(images_list)


In this section we are just using checks to guarantee that the pipeline won't break.

..  code-block:: python

    for i in range (0, num_frames):
        print("Running frame {}".format(images_list[i]))
        
        # Load an image using cv2.imread(). The image has 3 dimensions and
        # is in BGR format.
        bgr_image = cv2.imread(images_list[i])

We read the images from disk using the ``cv2.imread`` function.

..  code-block:: python

    preprocessed_image = image_preprocess(frame=bgr_image,
                                            norm_params = [[255.0, 0.485, 0.229],
                                                        [255.0, 0.456, 0.224],
                                                        [255.0, 0.406, 0.225]])

We perform some preprocessing steps, for this specific model we just need a resize operation as the ``image_preprocess`` ilustrates here:
Bear in mind that all the sima functions will guarantee the maximum possible performance. Therefore using sima.normalize will get you a higher fps than using ``cv2.normalize()``.
    
..  code-block:: python

    def image_preprocess(frame: np.ndarray, norm_params: List[Tuple[float, float, float]]) -> np.ndarray:
        """
        This function pre-processes an input frame that is in BGR
        format. Specifically, it normalizes the input
        frame. A normalized 3D output frame, which is
        in BGR format and has an HWC layout, is returned.
        """
        # Scale the input frame.

        # Normalize the scaled input frame.
        tensor_normalized = sima.normalize(frame,
                                        channel_params=norm_params)

        return tensor_normalized

After the preprocessing step, we simply run the created session by ``sima.MLSoCRT`` using ``sess.run_session`` checkout Chapter TODO {Peppi' API chapter number}

..  code-block:: python

        # Run inference on the 3D BGR frame and collect the single output
        # tensor produced by ResNet50.
        output_tensors = sess.run_session([preprocessed_image])

We assume that the model could have multiple inputs, therefore we use a list structure. Since this model has only a single output, we will use this one:

..  code-block:: python

        output_tensor = output_tensors[0]
        
        # The output is a single 1-based value represented as a 4D tensor.
        # Extract this value and determine the corresponding prediction label.
        prediction = output_tensor[0][0][0][0] - 1

We extract our prediction as mentioned in the code comments and classify it.

..  code-block:: python

        prediction_label = classify(id_label_dict, prediction)

The classify function:

..  code-block:: python

    def classify(id_label_dict: Dict, prediction: int) -> str:
        """
        This function extracts the class label from the given prediction.
        """
        if prediction >= len(id_label_dict.keys()):

            raise Exception(f"[ ERROR ] {prediction} must be less than {len(id_label_dict.keys())}")
        return id_label_dict[prediction]


Simply checks that the prediction is within bounds and extract the correct ID.
Finally we check that the prediction is not ``None`` and log it on the terminal.

..  code-block:: python

        if not prediction_label:
            raise Exception(f"[ ERROR ] Failed to get prediction label.")

        print(f"Image {images_list[i]} is {prediction_label}")

    # Perform cleanup before exiting.
    sess.release()

We can quickly imagine how we could run any model, simply change your ``tar.gz`` file and use your own pre and post processing blocks.
Using predefined sima calls will be more optimal than using external libraries for the same function.
All peppi functions try to mimic `python-opencv` nomenclature as ``sima.VideoCapture``, ``sima.resize``, ``sima.sigmoid``... Check out our API guide Chapter TODO {Peppi' API chapter number}.

Peppi APIs
==========

Session handling - MLSoCRT
--------------------------
.. function:: MLSoCRT(model_tgz_file_name:str, image_height:int=-1, image_width:int=-1, verbose:bool=False) -> MLSoCRT
    :module: sima

    This class is used to execute an ML model on the SoC. 
    It is assumed that an ML model has been compiled by the Model SDK into a ``tar.gz`` file that contains a set of ``.lm`` files that need to execute on the MLA, a set of ``.so`` files that need to execute on the ARM APU, and an ``mpk.json`` file that specifies how to orchestrate the execution of the ``.lm`` and ``.so`` files, as well as any SiMa-specific pre-processing and post-processing that must be performed.
    The caller may optionally specify the height and width of the incoming camera frames. If these values are not specified (default value of -1), they are automatically derived from the first captured frame.

    :param model_tgz_file_name: ``tar.gz`` file path associated with the model.
    :param image_height: height of the incoming camera frames, which is used internally for creating json files needed for decoding and encoding.  This field will be deprecated in the future.
    :param image_width: width of the incoming camera frames.  Also used internally for creating json files needed for decoding and encoding. This field will be deprecated in the future.
    :param verbose: optional parameter to be used for debugging.

    :returns: An initialized MLSoCRT object.


.. function:: sima.MLSoCRT.run_session(preprocessed_frames: List[np.ndarray]) -> List[np.ndarray]
    :module: sima

    This function runs inference on the passed-in input frames. The input frames are assumed to be in BGR format, and to have a 3D shape with an HWC layout. A list of Numpy arrays that correspond to the output tensor(s) is returned.  In general, each output tensor has a 4D shape with an NHWC layout, but this should be confirmed by inspecting the Numpy array.
    Parameters:

    :param preprocessed_frames: one or more input frames on which inference is to be performed. The input frames are assumed to be in BGR format, and to have a 3D shape with an HWC layout.  Additionally, the datatype must be ``float32``.

    :returns: A list of Numpy arrays that correspond to the output tensor(s) of the model.

.. function:: sima.MLSoCRT.release()
    :module: sima

    This function cleans up all internal resources associated with the ``MLSoCRT`` object.

VideoCapture
------------

.. function:: sima.VideoCapture(network_src:str, image_height: int=-1, image_width: int=-1) -> VideoCapture
    :module: sima

    This class is used for capturing input frames from a video source.  The caller may specify the desired height and width of the captured video frames.  If these values are not specified (default value of -1), they are automatically derived from the first captured frame.
    The video source may be an IP camera or UDP sink.  In the former case, we set up an RTSP client that talks to the RTSP server and receives H.264 encoded frames. Each H.264 frame is then decoded using the internal hardware-accelerated decoder, and the result is an NV12 frame. Finally, the NV12 frame is converted to BGR format using hardware acceleration and returned to the caller.

    :param network_src: network source, which may be an IP camera or UDP sink. If the source is an IP camera, this parameter must be a full RTSP URL of the form ``rtsp://<camera_ip>/<stream>``. Otherwise, this parameter must be a UDP port number.
    :param image_height: desired height of the captured video frame.
    :param image_width: desired width of the captured video frame.

    :returns: An initialized ``VideoCapture`` object.

.. function:: sima.VideoCapture.isOpened() -> bool
    :module: sima

    This function returns ``True`` if the video source has been opened.

    :returns: Boolean specifying whether or not the video capture has been opened.

.. function:: sima.VideoCapture.read() -> np.ndarray
    :module: sima

    This function reads a frame from the input video source and returns it.  The frame is assumed to be in BGR format with an underlying datatype of ``uint8``.

    :returns: Captured video frame in BGR format.

.. function:: sima.VideoCapture.get_height() -> int
    :module: sima

    This function returns the height of the captured video frame. This function should only be called after the first call to ``read()``.

    :returns: Height of the captured video frame.

.. function:: sima.VideoCapture.get_width() -> int
    :module: sima

    This function returns the width of the captured video frame. This function should only be called after the first call to ``read()``.

    :returns: Width of the captured video frame.

.. function:: sima.VideoCapture.release()
    :module: sima

    This function cleans up all internal resources associated with the ``VideoCapture`` object.

StreamVideo
-----------

.. function:: sima.StreamVideo(image_height: int, image_width: int, host_IP: str, gst_port: Optional[int]) -> StreamVideo
    :module: sima

    This class is used for displaying output video on a host.  Images to be displayed are assumed to be in BGR format.  We instantiate a Gstreamer pipeline, which uses the internal Allegro encoder; the incoming BGR frame is first converted to NV12 before being sent to the encoder which outputs H-264 encoded frame.
    H.264-encoded video, packages it for real-time transmission as MPEG2 TS stream, and sends it to a specified IP address and port over UDP.
    To instantiate the GStreamer pipeline, you will need to run the following command on your host: ``gst-launch <gst_string>``.

    :param image_height: height of the image to be displayed.
    :param image_width: width of the image to be displayed.
    :param host_IP: IP address of the host.
    :param gst_port: optional port number.

    :returns: An initialized ShowVideo object.

    Users can use the ffplay command or vlc to display the stream on the host you are streaming the video to. Assuming you are sending the stream to port ``9000`` as in your GStreamer pipeline, you can run ``ffplay/vlc`` as follows:

    ``ffplay udp://localhost:9000`` or ``vlc udp://localhost:9000``

.. function:: sima.ShowVideo.imshow(bgr_frame: np.ndarray) -> int
    :module: sima

    This function displays the input frame on the host. The input frame, which is assumed to be in BGR format.

    :param bgr_frame: the video frame to be displayed. Number of channels can only be 3 and that the data type can only be ``np.uint8``.

    :returns: Integer error code.

Image Pre-Processing
--------------------

PePPi APIs are provided for common image pre-processing functions.  These functions, which include scaling and normalization, are applicable to all input images that are in BGR format.  Be sure to reference the fp32 pipeline in order to determine the specific image pre-processing that is required.

The pre-processing APIs available to users are specified below:

.. function:: sima.resize(data: np.ndarray, target_height: int, target_width: int, keep_aspect: bool, deposit_location: str = 'center', method: str = 'linear') -> np.ndarray
    :module: sima


    This function resizes the input frame to the target dimensions, then returns the resized frame. Both the input and output frames are assumed to be in BGR format, and to have a 3D shape with an HWC layout.

    :param data: input frame to be resized in BGR format, with 3D shape (HWC) and datatype of uint8.
    :param target_height: height to which the frame is to be resized.
    :param target_width: width to which the frame is to be resized.
    :param keep_aspect: boolean that specifies whether or not to keep the aspect ratio during the resize operation.
    :param deposit_location: string that specifies where to place the resized image within the padded frame.  Permissible values are: ``center`` (default), ``topleff``, and ``bottomright``.
    :param method: interpolation algorithm to be used during the resize operation. Supported methods are ``linear``, ``nearest``, ``area``, and ``cubic``.

    :returns: A Numpy array that represents the resized input frame in BGR format, with 3D shape and data type of uint8.

.. function:: sima.normalize(bgr_frame: np.ndarray, channel_params: List[Tuple[float, float, float]]) -> np.ndarray
    :module: sima

    This function normalizes the input frame with the given channel parameters, then returns the normalized frame.  Both the input and output frames are assumed to be in BGR format, and to have a 3D shape with an HWC layout. The channel parameters are assumed to be in RGB order.

    :param bgr_frame: input frame to be normalized in BGR format with 3D shape, HWC layout, and an underlying datatype of ``uint8``.
    :param channel_params: per-channel scale, mean, and sigma values.

    :returns: A Numpy array that represents the normalized input frame in BGR format, with 3D shape, HWC layout, and an underlying datatype of ``float32``.

Output Post-Processing
----------------------

PePPi APIs are provided for common post-processing functions.  In addition to using these APIs, users may also write their own custom post-processing code in Python and invoke this code from their inference scripts. The post-processing APIs available to users are specified below:

.. function:: sima.sigmoid(data: np.ndarray, save_int16: bool) -> np.ndarray
    :module: sima

    This function performs the sigmoid computation on the input tensor, then returns the output of the computation. Both the input and output tensors are assumed to have a 4D shape with an NHWC layout.

    :param data: input tensor to which sigmoid is to be applied.The shape should be 4D in NHWC layout. The input datatype is expected to be ``float32``.
    :param save_int16: boolean that specifies whether or not to convert the sigmoid output to an int16 value for reducing bandwidth.

    :returns: Output of the sigmoid computation.

.. function:: sima.centernet_nms_maxpool(data: np.ndarray, kernel: int) -> np.ndarray
    :module: sima

    This function performs the nms maxpool computation on the input tensor, then returns the output of the computation.  Both the input and output tensors are assumed to have a 4D shape with an NHWC layout.  This particular operation is specific to the CenterNet model.

    :param data: input tensor to which nms maxpool is to be applied.
    :param kernel: maxpool kernel size, which must be an odd number.

    :returns: Output of the nms maxpool computation.