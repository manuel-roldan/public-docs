.. _Quick start guide:

Quick start guide
#################