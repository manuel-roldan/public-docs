.. SiMa.ai documentation master file, created by
   sphinx-quickstart on Tue Oct 31 10:32:30 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SiMa's developer journey!
====================================

Get everything you need to work with Sima in just a few easy steps:

#. `Purchase a Sima Developer Kit <https://google.com/>`_ and check the documentation links below for initial setup and more.
#. Check out our examples, tutorials, or jump right in to `our AI Courses <https://sima.aii/>`_.
#. `Sign up for SiMa's Zendesk <https://sima.ai.dumb/>`_ to ask questions and receive help.
#. `Log in into SiMa's GitHub <https://sima.ai.dumb/>`_ to get our latest models.

Installation guides
===================

:ref:`Quick start guide`
------------------------

This guide provides the minimal first-steps instructions for installation and verification of your Sima devkit.

:ref:`fw_boardsw`
-----------------

This guide discusses how to install and check for correct operation of the firmware and the board software.

:ref:`palette_cli`
------------------

This guide discusses how to install and check for correct operation of Palette CLI.

Running pipelines - Platforms
=============================

`Edgematic <https://sima.ai.dumb/>`_
------------------------------------

Jump right into our noplatform! No guide needed, our noplatform is the easiest platform to develop pipelines and we provide an in place tutorial! It's simple, log in, learn how to with the start up tutorial, and develop entire pipelines without writing any code.

:ref:`gstreamer`
----------------

This guide provides a detailed discussion of the use of Gstreamer to run pipelines on SiMa's boards. This platform will achieve the maximum performance in our boards! However, it is the most challenging platform but don't worry we will make it easy just for you.

:ref:`peppi`
------------

This guide provides a detailed discussion of the use of python to run pipelines on SiMa's boards. This platform will achieve the functional ~10 fps performance in our boards. It is medium challenge platform since you will be able to use your well known python packages on the board to process your pre and post processing steps.

:ref:`model_accelerator`
------------------------

This guide provides a detailed discussion of how to use the board as an accelerator to run models on SiMa's boards. This platform will achieve the minimum performance in our boards. However, it is the easiestimplementation since the pre and post processing blocks will be running on a host machine.


Become a pro!
=============

Advanced guides

:ref:`running_on_board`
-----------------------

#. Booting modes
#. Connection modes
#. Performance estimation
#. Remote debugging
#. Running pipelines from booting

:ref:`benchmarking`
-------------------

#. MLperf 
#. Running benchmarks

:ref:`depth_explanation`
------------------------

#. SW architecture
#. HW architecture

:ref:`lets_develop`
-------------------

#. APIs
#. Transforms
#. Plugins
#. Defining ANY
#. Defining requirements to run in A65
#. Defining requirements to run in MLA
#. Defining requirements to run in EV74


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

